package com.cmedhealth.prescriptiongenerator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrescriptionGeneratorApplicationTests {

	@Test
	void contextLoads() {
	}

}
