package com.cmedhealth.prescriptiongenerator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrescriptionGeneratorApplication {

	public static void main(String[] args) {
		SpringApplication.run(PrescriptionGeneratorApplication.class, args);
	}

}
